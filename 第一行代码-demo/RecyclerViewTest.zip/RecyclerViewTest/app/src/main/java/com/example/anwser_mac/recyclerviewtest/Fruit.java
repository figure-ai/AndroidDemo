package com.example.anwser_mac.recyclerviewtest;

/**
 * Created by anwser_mac on 2017/3/31.
 */

public class Fruit {
    private String name;
    private int imageId;

    public Fruit(String name, int imageId) {
        this.name = name;
        this.imageId = imageId;
    }

    public String getName() {
        return name;
    }

    public int getImageId() {
        return imageId;
    }
}
